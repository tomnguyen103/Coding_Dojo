package com.tomnguyen7.driverslicense;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriverslicenseApplicationTests {

	@Test
	void contextLoads() {
	}

}
