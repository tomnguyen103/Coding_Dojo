package com.tomnguyen7.driverslicense;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriverslicenseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DriverslicenseApplication.class, args);
	}

}
