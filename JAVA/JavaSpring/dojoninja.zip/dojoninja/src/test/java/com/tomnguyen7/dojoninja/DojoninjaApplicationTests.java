package com.tomnguyen7.dojoninja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojoninjaApplicationTests {

	@Test
	void contextLoads() {
	}

}
