from django.apps import AppConfig


class PoorlyCodedStoreConfig(AppConfig):
    name = 'poorly_coded_store'
